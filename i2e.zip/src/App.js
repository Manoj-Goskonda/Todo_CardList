import React from "react";
// import './App.css';
import "./index.css";
import FormData from "./FormData";

function App() {
  return (
    <>
      <FormData />
    </>
  );
}

export default App;
